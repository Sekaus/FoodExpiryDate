package net.mcreator.foodexpirydate.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent.LevelTickEvent;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.registries.ForgeRegistries;

import net.mcreator.foodexpirydate.network.FoodExpiryDateModVariables;
import net.mcreator.foodexpirydate.SetFoodExpiryState;
import net.mcreator.foodexpirydate.init.FoodExpiryDateModBlocks;
import net.mcreator.foodexpirydate.FoodExpiryDateMod;
import net.mcreator.foodexpirydate.block.entity.FreezerBlockEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class FoodExpiryDateForInventoryProcedure {

    @SubscribeEvent
    public static void onWorldTick(LevelTickEvent event) {
        if (event.phase != LevelTickEvent.Phase.END) return;
        LevelAccessor worldAcc = event.level;
        if (worldAcc.isClientSide()) return;
        execute(worldAcc);
    }

    private static void execute(@Nullable LevelAccessor worldAcc) {
        if (!(worldAcc instanceof Level world)) return;

        int rawRadius = 8;
        int radius = (int) Math.ceil(rawRadius);
        if (radius < 1) return;

        // Iterate directly over the list of players
        for (Player player : world.players()) {
            BlockPos center = player.blockPosition();

            // Scan block inventories in a cube around the player
            for (int x = center.getX() - radius; x <= center.getX() + radius; x++) {
                for (int y = center.getY() - radius; y <= center.getY() + radius; y++) {
                    for (int z = center.getZ() - radius; z <= center.getZ() + radius; z++) {
                        BlockPos pos = new BlockPos(x, y, z);

                        BlockEntity be = world.getBlockEntity(pos);
                        if (be == null) continue;

                        be.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(handler -> {
                            if (handler instanceof IItemHandlerModifiable modHandler) {
                            	if (be instanceof FreezerBlockEntity) {
                                	applyExpiryLogic(world, handler, modHandler::setStackInSlot, true);
                            	}
                            	else {
                            		applyExpiryLogic(world, handler, modHandler::setStackInSlot);
                            	}
                            }
                        });
                    }
                }
            }

            // Then update the player's own inventory
            player.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(handler -> {
                if (handler instanceof IItemHandlerModifiable modHandler) {
                    applyExpiryLogic(world, handler, modHandler::setStackInSlot);
                }
            });
        }
    }

    private static void applyExpiryLogic(LevelAccessor world, IItemHandler handler, SetFoodExpiryState.SlotSetter setter) {
    	applyExpiryLogic(world, handler, setter, false);
    }

    private static void applyExpiryLogic(LevelAccessor world, IItemHandler handler, SetFoodExpiryState.SlotSetter setter, boolean changeDateToToday) {
    	double days = FoodExpiryDateModVariables.MapVariables.get(world).daysPassed;
    	
        for (int slot = 0; slot < handler.getSlots(); slot++) {
            ItemStack stack = handler.getStackInSlot(slot).copy();
            SetFoodExpiryState.UpdateExpiryState(days, stack, world, setter, slot, changeDateToToday);
        }
    }
}
