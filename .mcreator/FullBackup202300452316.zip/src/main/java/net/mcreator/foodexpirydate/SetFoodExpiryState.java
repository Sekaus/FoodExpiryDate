/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.foodexpirydate as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.foodexpirydate;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.ai.behavior.UpdateActivityFromSchedule;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import it.unimi.dsi.fastutil.Stack;

import net.mcreator.foodexpirydate.init.FoodExpiryDateModItems;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SetFoodExpiryState {
	public static boolean IsFood(ItemStack stack) {
			return stack.getItem().isEdible() || stack.getItem() == Items.MILK_BUCKET || stack.getItem() == Items.EGG || stack.getItem() == Items.CAKE;
		}

	public static void UpdateExpiryState(double days, ItemStack stack, LevelAccessor world, boolean changeDateToToday) {
			UpdateExpiryState(days, stack, world, null, -1, changeDateToToday);
		}
		
	public static void UpdateExpiryState(double days, ItemStack stack, LevelAccessor world, SlotSetter setter, int slot, boolean changeDateToToday) {
		if (!stack.isEmpty()) {

        boolean food = IsFood(stack);
        boolean dried = stack.getOrCreateTag().getBoolean("dried");
        boolean dateSet = stack.getOrCreateTag().getBoolean("dateSet");

        if (!dried && food) {
        	if (!dateSet) {
        		stack.getOrCreateTag().putDouble("creationDate", days);
                stack.getOrCreateTag().putBoolean("dateSet", true);
                if (slot > -1)
                	setter.set(slot, stack);
                } 
                else if (days - stack.getOrCreateTag().getDouble("creationDate") > 5 && !changeDateToToday) {
                    ItemStack moldy = stack.getItem() == Items.MILK_BUCKET
                        ? new ItemStack(FoodExpiryDateModItems.MOLDY_MILK.get())
                        : new ItemStack(FoodExpiryDateModItems.MOLDY_FOOD.get());
                    moldy.setCount(stack.getCount());
                    if(slot > -1)
                    	setter.set(slot, moldy);
                }


                if (changeDateToToday) {
                	stack.getOrCreateTag().putDouble("creationDate", days);
                	if (slot > -1) {
					  setter.set(slot, stack);
					}
                }
            }
		}
	}

	@FunctionalInterface
    public interface SlotSetter {
        void set(int slot, ItemStack newStack);
    }
}
