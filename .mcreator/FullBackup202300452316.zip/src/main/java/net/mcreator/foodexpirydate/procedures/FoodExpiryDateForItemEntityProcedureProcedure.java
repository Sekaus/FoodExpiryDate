package net.mcreator.foodexpirydate.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import javax.annotation.Nullable;

import net.mcreator.foodexpirydate.network.FoodExpiryDateModVariables;
import net.mcreator.foodexpirydate.SetFoodExpiryState;

@Mod.EventBusSubscriber
public class FoodExpiryDateForItemEntityProcedureProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getLevel(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity instanceof ItemEntity _itemEnt) {
		    ItemStack original = _itemEnt.getItem();
		
		    if (!original.getOrCreateTag().getBoolean("dateSet") && SetFoodExpiryState.IsFood(original)) {
		        // Clone to decouple from original inventory
		        ItemStack copy = original.copy();
		
		        double days = FoodExpiryDateModVariables.MapVariables.get(world).daysPassed;
		        SetFoodExpiryState.UpdateExpiryState(days, copy, world, false);
		        copy.getOrCreateTag().putBoolean("dateSet", true);
		
		        // Server-side replacement
		        if (!world.isClientSide() && world instanceof ServerLevel _level) {
		            entity.discard();
		            ItemEntity newEntity = new ItemEntity(_level, x, y, z, copy);
		            newEntity.setPickUpDelay(10);
		            _level.addFreshEntity(newEntity);
		        }
		    }
		}
	}
}
