
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foodexpirydate.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.foodexpirydate.block.FreezerBlock;
import net.mcreator.foodexpirydate.block.FoodDryingRackBlock;
import net.mcreator.foodexpirydate.FoodExpiryDateMod;

public class FoodExpiryDateModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FoodExpiryDateMod.MODID);
	public static final RegistryObject<Block> FOOD_DRYING_RACK = REGISTRY.register("food_drying_rack", () -> new FoodDryingRackBlock());
	public static final RegistryObject<Block> FREEZER = REGISTRY.register("freezer", () -> new FreezerBlock());
}
