
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foodexpirydate.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.foodexpirydate.FoodExpiryDateMod;

public class FoodExpiryDateModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FoodExpiryDateMod.MODID);
	public static final RegistryObject<CreativeModeTab> FOOD_EXPIRY_DATE = REGISTRY.register("food_expiry_date",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.food_expiry_date.food_expiry_date")).icon(() -> new ItemStack(FoodExpiryDateModItems.MOLDY_MILK.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FoodExpiryDateModItems.MOLDY_MILK.get());
				tabData.accept(FoodExpiryDateModItems.MOLDY_FOOD.get());
				tabData.accept(FoodExpiryDateModBlocks.FOOD_DRYING_RACK.get().asItem());
				tabData.accept(FoodExpiryDateModBlocks.FREEZER.get().asItem());
			})

					.build());
}
