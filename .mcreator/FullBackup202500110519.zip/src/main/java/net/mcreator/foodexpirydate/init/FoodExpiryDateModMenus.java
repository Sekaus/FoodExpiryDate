
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.foodexpirydate.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.foodexpirydate.world.inventory.FreezerGUIMenu;
import net.mcreator.foodexpirydate.world.inventory.FoodDryingRackGUIMenu;
import net.mcreator.foodexpirydate.FoodExpiryDateMod;

public class FoodExpiryDateModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, FoodExpiryDateMod.MODID);
	public static final RegistryObject<MenuType<FoodDryingRackGUIMenu>> FOOD_DRYING_RACK_GUI = REGISTRY.register("food_drying_rack_gui", () -> IForgeMenuType.create(FoodDryingRackGUIMenu::new));
	public static final RegistryObject<MenuType<FreezerGUIMenu>> FREEZER_GUI = REGISTRY.register("freezer_gui", () -> IForgeMenuType.create(FreezerGUIMenu::new));
}
