package net.mcreator.foodexpirydate;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.items.IItemHandlerModifiable;

import net.mcreator.foodexpirydate.init.FoodExpiryDateModItems;
import net.mcreator.foodexpirydate.ThingsThatCanExpire;

/**
 * The code in this class handles setting and updating the expiry state of food items.
 * It is now more robust to prevent inventory synchronization issues.
 */
@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SetFoodExpiryState {

    /**
     * Updates the expiry state of a single food item.
     * This method handles both setting the initial expiry date and replacing the item with a rotten version.
     *
     * @param days The current number of days passed in the game.
     * @param stack The item stack to update. This is the original stack from the inventory handler.
     * @param world The world accessor.
     * @param handler The item handler (IItemHandlerModifiable) that contains the stack.
     * @param slot The slot index of the stack within the handler.
     * @param changeDateToToday If true, forces the creation date to be set to the current day. This is used for freezers.
     */
    public static void updateExpiryState(double days, ItemStack stack, LevelAccessor world, IItemHandlerModifiable handler, int slot, boolean changeDateToToday) {
        // Only proceed if the stack is not empty.
        if (stack.isEmpty()) {
            return;
        }

        boolean isFood = ThingsThatCanExpire.isFood(stack);
        boolean isDried = stack.getOrCreateTag().getBoolean("dried");
        boolean dateSet = stack.getOrCreateTag().getBoolean("dateSet");

        // The expiry logic only applies to food that has not been dried.
        if (!isDried && isFood) {
            // Case 1: The item has no expiry date tag.
            // This is a new item, so we set its creation date.
            if (!dateSet) {
                stack.getOrCreateTag().putDouble("creationDate", days);
                stack.getOrCreateTag().putBoolean("dateSet", true);
                handler.setStackInSlot(slot, stack);
            }
            // Case 2: The item is in a freezer.
            // We force the creation date to be reset to the current day.
            else if (changeDateToToday) {
                stack.getOrCreateTag().putDouble("creationDate", days);
                handler.setStackInSlot(slot, stack);
            }
            // Case 3: The item is expired and not in a freezer.
            // Replace the food with its rotten version.
            else if (days - stack.getOrCreateTag().getDouble("creationDate") > 5) {
                ItemStack moldyStack = ThingsThatCanExpire.getRotten(stack);
                moldyStack.setCount(stack.getCount()); // Retain the original stack size.
                handler.setStackInSlot(slot, moldyStack);
            }
        }
    }
}
