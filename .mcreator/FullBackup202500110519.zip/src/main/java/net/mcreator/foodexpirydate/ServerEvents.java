package net.mcreator.foodexpirydate;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Forge event subscriber for server lifecycle events.
 * Registered automatically via the annotation (Forge Event Bus).
 */
@Mod.EventBusSubscriber(modid = "foodexpirydate", bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ServerEvents {

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        System.out.println("[CustomDisplay] ServerStoppingEvent: cleaning up all display entities.");
        DisplayRegistry.cleanupAll();
    }
}
