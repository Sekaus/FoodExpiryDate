/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.foodexpirydate as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.foodexpirydate;

import net.minecraftforge.common.IPlantable;
import net.minecraftforge.common.PlantType;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.foodexpirydate.init.FoodExpiryDateModItems;
import net.mcreator.foodexpirydate.init.FoodExpiryDateModBlocks;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ThingsThatCanExpire {
	public static boolean isFood(ItemStack stack) {
			Item item = stack.getItem();
			
			return (
				item.isEdible() || 
				item == Items.MILK_BUCKET || 
				item == Items.EGG || 
				item == Items.CAKE ||
				item == Items.DRIED_KELP_BLOCK ||
				item == Items.MELON ||
				item == Items.PUMPKIN
			) && (
				(item != FoodExpiryDateModItems.MOLDY_FOOD.get()) || 
				(item != FoodExpiryDateModItems.MOLDY_MILK.get()) || 
				(item != FoodExpiryDateModItems.MOLDY_BLOCK.get())
			);
				
	}

	public static boolean isFood(Block block) {
		return ( 
				block == Blocks.MELON ||
				block == Blocks.PUMPKIN ||
				block == Blocks.MELON ||
				block == Blocks.DRIED_KELP_BLOCK ||
				block == Blocks.CHORUS_FLOWER ||
				block == Blocks.KELP
			) && block != FoodExpiryDateModBlocks.MOLDY_BLOCK.get();
	}

	public static boolean isBlockFood(Level level, BlockState state, BlockPos pos) {
		Block block = state.getBlock();
		ResourceLocation registryName = ForgeRegistries.BLOCKS.getKey(block);
		
		if (block instanceof IPlantable) {
			PlantType type = ((IPlantable) block).getPlantType(level, pos);
		    return 
		        type == PlantType.CROP &&
		        (block != Blocks.MELON_STEM || block != Blocks.PUMPKIN_STEM);
		}
		else {
			String stringName = registryName.toString();
			return 
				stringName.contains("cake") ||
				stringName.contains("kelp") ||
				isFood(block);
		}
	}
	
	public static ItemStack getRotten(ItemStack stack) {
	    Item item = stack.getItem();
	
	    if (item == Items.MILK_BUCKET)
	        return new ItemStack(FoodExpiryDateModItems.MOLDY_MILK.get());
	    else if (isFood(stack)) {
	    	if(item == Items.MELON || item == Items.PUMPKIN)
	    		return new ItemStack(FoodExpiryDateModItems.MOLDY_BLOCK.get());
	    	else
	        	return new ItemStack(FoodExpiryDateModItems.MOLDY_FOOD.get());
	    }
	    else
	        return stack;
	}
}
